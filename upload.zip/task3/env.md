- 结果展示见截图。

- python、vscode之前就安装过，有什么问题已经忘了。Apifox和IDEA安装很顺利，主要是nodejs安装时环境配置时出了点小插曲，已通过寻找教程解决。
