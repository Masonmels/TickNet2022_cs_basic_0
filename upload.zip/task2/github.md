- 仓库地址：https://github.com/Masonmels/login_register.git
  
  - 

- 提交pr：
  
  - 将远程仓库clone下来。
  
  - 进入该文件夹，打开bash。
  
  - 创建一个你的分枝，并切换到该分支。
  
  - 修改代码。
  
  - git status：查看你该了哪些文件，可用cat命令查看具体更改内容。
  
  - git add .
  
  - git commit -m 'xxx'
  
  - git push --set-upstream origin 你创建的分枝名
  
  - 然后就提交成功了。
  
  - 进入github->pr板块，进入你的分枝，创建pr，你将看到你更改的内容，然后提交即可，等待作者审核。

- 合并pr：即合并分枝，略。

参考文章：[点我！](https://blog.csdn.net/gentleman_hua/article/details/123816150)
