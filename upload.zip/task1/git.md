- 版本控制相关命令：
  
  首先新建空文件夹，在git bash中输入以下命令：
  
  - git init：创建仓库。
  
  - git add 文件名：把文件添加到暂存区，注意首先得把文件放在改文件夹下。
  
  - git commit -m '本次提交写的注释/说明'：把上面那个文件提交到仓库。
  
  - git log：查看历史提交。
  
  - git reset --hard HEAD^：回退到上一次提交，上上次则“HEAD^^”，上100次则“HEAD~100”。
  
  - git checkout -b 分枝名：创建并切换到新建分枝。
  
  - git branch -d 分枝名：删除分枝，注意此时不能停留在待删分枝上。
  
  - git merge 分枝名：将命令中的分枝合并到当前分枝上。
  
  参考教程：[点我！](https://blog.csdn.net/u011535541/article/details/83379151)


